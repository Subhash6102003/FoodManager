package com.example.foodmanager

class ItemData(var itemname: String, var desc: String, var price: Int)
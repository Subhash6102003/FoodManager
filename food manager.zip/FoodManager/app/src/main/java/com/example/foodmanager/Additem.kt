package com.example.foodmanager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.foodmanager.R

class Additem : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.additem)

        // Finding views by their IDs
        val titleTextView: TextView = findViewById(R.id.titleTextView)
        val itemNameEditText: EditText = findViewById(R.id.itemNameEditText)
        val itemPriceEditText: EditText = findViewById(R.id.itemPriceEditText)
        val itemImageView: ImageView = findViewById(R.id.itemImageView)
        val shortDescriptionEditText: EditText = findViewById(R.id.shortDescriptionEditText)
        val ingredientsEditText: EditText = findViewById(R.id.ingredientsEditText)
        val addItemButton: Button = findViewById(R.id.addItemButton)

        // Setting up your UI components
        titleTextView.text = "Add Item"

        // Set up your button click listener here
        addItemButton.setOnClickListener {
            // Perform actions when the button is clicked
        }
    }
}

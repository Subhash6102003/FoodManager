package com.example.foodmanager

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class Uploaditem : AppCompatActivity() {
    private lateinit var itemListLayout: LinearLayout
    private var itemCount = 0

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.additem)

        itemListLayout = findViewById(R.id.item_list)

        val btnAddMoreItems: Button = findViewById(R.id.btn_add_more_items)
        btnAddMoreItems.setOnClickListener {
            addNewItem()
        }
    }

    private fun addNewItem() {
        val layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        val itemContainer =
            LayoutInflater.from(this).inflate(R.layout.allitem, null) as LinearLayout
        itemContainer.layoutParams = layoutParams

        itemCount++

        val itemName = createEditText("Item Name $itemCount", 18f)
        val itemDescription = createEditText("Item Description $itemCount", 16f)
        val itemPrice = createEditText("Price (USD) $itemCount", 16f)
        val btnUploadImage = createButton("Upload Image")
        val selectedImage = createImageView()

        btnUploadImage.setOnClickListener {
            openImageChooser(selectedImage)
        }

        itemContainer.addView(itemName)
        itemContainer.addView(itemDescription)
        itemContainer.addView(itemPrice)
        itemContainer.addView(btnUploadImage)
        itemContainer.addView(selectedImage)

        itemListLayout.addView(itemContainer)
    }

    private fun createEditText(hint: String, textSize: Float): EditText {
        val editText = EditText(this)
        editText.hint = hint
        editText.textSize = textSize
        editText.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = resources.getDimensionPixelSize(R.dimen.item_field_margin)
        }
        return editText
    }

    private fun createButton(text: String): Button {
        val button = Button(this)
        button.text = text
        button.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            topMargin = resources.getDimensionPixelSize(R.dimen.item_field_margin)
        }
        return button
    }

    private fun createImageView(): ImageView {
        val imageView = ImageView(this)
        imageView.layoutParams = LinearLayout.LayoutParams(
            resources.getDimensionPixelSize(R.dimen.image_size),
            resources.getDimensionPixelSize(R.dimen.image_size)
        ).apply {
            topMargin = resources.getDimensionPixelSize(R.dimen.item_field_margin)
        }
        imageView.visibility = View.GONE
        return imageView
    }

    private val imagePickerActivityResult =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                data?.let {
                    val selectedImageUri = it.data
                    val imageViewId = it.getIntExtra("imageViewId", 0)
                    val imageView = findViewById<ImageView>(imageViewId)
                    imageView.setImageURI(selectedImageUri)
                    imageView.visibility = View.VISIBLE
                }
            }
        }

    private fun openImageChooser(imageView: ImageView) {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.putExtra("imageViewId", imageView.id)
        imagePickerActivityResult.launch(intent)
    }
}

